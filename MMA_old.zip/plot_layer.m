function plot_layer(x)
% this file plots layer-by-layer plot in the print plane 
global nelx nely 

%
rho = x(1:length(x)/2); theta = x(length(x)/2+1:end); 
rho = reshape(rho,nely,nelx); 
theta = reshape(theta,nely,nelx);
% ielem1 = ielem((find(rho>.5)),:); rho1 = rho(find(rho>.5),:); theta1= theta(find(rho>.5),:);
%
[XC,YC]=meshgrid(1:nelx,1:nely);

% PLOT DENSITIES
figure(1);
colormap(gray); imagesc(rho); axis equal; axis tight; axis off;

figure(2);
quiver(XC(:), YC(:), cos(theta(:)) , sin(theta(:)),0.6,'r','ShowArrowHead', false);
