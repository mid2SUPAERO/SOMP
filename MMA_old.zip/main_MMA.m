%%%% A 99 LINE TOPOLOGY OPTIMIZATION CODE BY OLE SIGMUND, JANUARY 2000 %%%
%%%% A 142 LINE CODE MODIFIED FOR USE WITH ORTHOTROPIC MATERIALS %%% 
%function TopO(nelx,nely,volfrac,angle,penal,rmin);
% INITIALIZE
clear all; close all;
global nelx nely vol volfrac ang angle  penal rmin

nelx=10;
nely=10;
volfrac=0.5;
angle=pi;
penal=3;
rmin=1.5;




c0 = volfrac;
rho0 = volfrac*ones(nely,nelx); 
theta0 = angle*ones(nely,nelx);
nele=nelx*nely;
% define phi (rotation about y axis) 
% offset = 0;
% a = -offset/180*pi; b = offset/180*pi;
% phi = a + (b-a)*rand(nele,1); 
% phi = reshape(phi,nely,nelx); %
%
x0 = [rho0(:);theta0(:)];
lb = [1E-6*ones(length(rho0(:)),1);-pi/2*ones(length(theta0(:)),1)];
ub = [ones(length(rho0(:)),1);pi/2*ones(length(theta0(:)),1)];
%
% equality constraint
Aeq = [ones(1,length(rho0(:))) zeros(1,length(theta0(:)))]; 
beq = nelx*nely*c0;
% fmincon % add @top_nonlcon (only for passive element) 
%x = fmincon('top_obj',x0,[],[],Aeq,beq,lb,ub,[],option); 
%plot_layer(x) 
options = struct(...
    'a0',1,...
    'a',0,...
    'c_mma',1000,...
    'd',1,...
    'asyinit',0.4,...
    'asyincr',1.2,...
    'asydecr',0.7,...
    'MaxIter',1000,...
    'MaxInnerIter',50,...
    'raa0eps',0.00001,...
    'raaeps',0.000001,...
    'epsimin',0.0000001,...
    'PlotFcns',[],...
    'NLPsolver','mma',...
    'TolX',1e-5,...
    'TolFun',1e-5,...
    'TolCon',1e-5,...
    'max_cpu_time',inf,...
    'low',[],...
    'upp',[],...
    'Display',[],...
    'ldl',false);
[xval,fval,exitflag,output,lambda,grad,hessian] = ...
    mma_main('top_obj',x0,[],[],Aeq,beq,lb,ub,[],options);
x=xval;
%
rho = x(1:length(x)/2); theta = x(length(x)/2+1:end); 
rho = reshape(rho,nely,nelx); 
theta = reshape(theta,nely,nelx);
% ielem1 = ielem((find(rho>.5)),:); rho1 = rho(find(rho>.5),:); theta1= theta(find(rho>.5),:);
%
[XC,YC]=meshgrid(1:nelx,1:nely);

% % PLOT DENSITIES
% figure(1);
% colormap(gray); imagesc(-rho); axis equal; axis tight; axis off;
% 
% figure(2);
% quiver(XC(:), YC(:), cos(theta(:)) , sin(theta(:)),0.6,'r','ShowArrowHead', false);
% 

rho_plot = 1-rho(:,:); %rho_plot = rho_plot(:);
%theta_plot = theta(:,:); %theta_plot = theta_plot(:);
% plot density 
%
[XC,YC]=meshgrid(1:nelx,1:nely);

% % PLOT DENSITIES
 figure(1);
colormap(gray); imagesc(flipud(rho_plot)); axis equal; axis tight; axis off;
hold on;
 quiver(XC, YC, cos(theta) , sin(theta),0.6,'r','ShowArrowHead', false);axis equal; axis tight; axis off;
%

% dim must be odd
dim = 1;
sigma = dim/7;
filter = gaussian2d(dim,sigma);
dim = size(filter,1);
thetaOpt = padarray(theta,[floor(dim/2) floor(dim/2)],'symmetric','both');
thetaOpt = conv2(thetaOpt,filter,'valid');
%thetaOpt = reshape(thetaOpt,1,[]);

figure(2)
 colormap(gray); imagesc(rho_plot); axis equal; axis tight; axis off;
hold on;
 quiver(XC, YC, cos(thetaOpt) , sin(thetaOpt),0.6,'r','ShowArrowHead', false);axis equal; axis tight; axis off;
%

figure(3);
heatmap(rad2deg(thetaOpt));
colormap(jet(512))



