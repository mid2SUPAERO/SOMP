function f=gaussian2d(N,sigma)
% Normalized Gaussian Filter
% N is the size of the filter
    if N == 1
        f = 1;
    else
        n = (N-2);
        [x,y]=meshgrid(round(-n/2):round(n/2), round(-n/2):round(n/2));
        f=exp(-x.^2/(2*sigma^2)-y.^2/(2*sigma^2));
        f(x.^2+y.^2>round(n/2)^2)=0;
        f=f./sum(f(:));
        
        figure
        surf(x,y,f);
        title({['Normalized Gaussian filter - Dimension ', num2str(N),'x',num2str(N)]; ['Sigma = ', num2str(sigma)]})
        xlabel('Dimension X')
        ylabel('Dimension Y')
        zlabel('Weight of the filter')
    end
end